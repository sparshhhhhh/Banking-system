# Basic_Banking_System

Description : A simple banking system website where we can transfer the money and checks our transaction history also we check our money balance .This is connected to database all the transaction will reflect in database also . To use my project you can download my code and also import my sql file in mysql .To see php part go with 000webhost website link .


# Build With
<ul>
  <li><a href="https://www.w3schools.com/html/">HTML</a> - Structure of Web Page</li>
  <li><a href="https://www.w3schools.com/css/">CSS</a> - Styling of Web Page</li>
  <li><a href="https://www.w3schools.com/bootstrap/bootstrap_ver.asp">BootStrap</a> - Open-source CSS Framework</li>
  <li><a href="https://www.w3schools.com/js/">JavaScript</a> - Programming Language for the Web Page</li>
  <li><a href="https://www.w3schools.com/php/">PHP</a> - Server Scripting Language of Web Page</li>
  <li><a href="https://www.w3schools.com/sql/">SQL</a> - Database</li>
  <li><a href="https://fontawesome.com/">Font Awesome</a> - The iconic SVG, font, and CSS toolkit</li>
  <li><a href="https://fonts.google.com/">Google Fonts</a> - Library of libre licensed fonts</li>
</ul>


000webhost website link : https://sparksproject18.000webhostapp.com/BasicBankingSystem/index.html

Github Website link : https://amanj-18.github.io/Basic-Banking-System/

Preview :

![image](https://user-images.githubusercontent.com/89749348/190688020-4c49174d-b30a-49e9-8619-907e773d70b2.png)
![image](https://user-images.githubusercontent.com/89749348/190688091-4b50c68d-7443-4f23-b55e-0304a6ce8f75.png)
![image](https://user-images.githubusercontent.com/89749348/190688148-3c30ddff-c61a-4498-a257-d615ace3cb05.png)
![image](https://user-images.githubusercontent.com/89749348/190688208-e1dd4971-fb92-45ef-963e-a2998fef2161.png)
![image](https://user-images.githubusercontent.com/89749348/190688254-d0ab8087-fb12-4ad4-ab7f-ddd4fb2d8f1b.png)
